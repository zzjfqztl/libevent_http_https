#ifndef HTML_H_DEFINED_
#define HTML_H_DEFINED_

/** 读取404的html页面
 */
char *HTTP_NotFound();

/** 读取403的html页面
 */
char *HTTP_Forbidden();

#endif